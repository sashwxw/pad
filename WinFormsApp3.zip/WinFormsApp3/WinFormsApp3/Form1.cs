namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double wynik=0;
            
            if (checkBox1.Checked)
            {
                wynik = wynik + 300;
            }
            if(checkBox2.Checked)
            {
                wynik = wynik + 100;
            }
            if (checkBox3.Checked)
            {
                wynik = wynik + 400;
            }
            if(checkBox4.Checked)
            {
                wynik = wynik + 120;
            }
            if (checkBox5.Checked)
            {
                wynik = wynik + 90;
            }
            if (wynik == 0)
            {
                MessageBox.Show("Musisz wybra� co najmniej jedn� us�ug�.");
            }
            else
            {
                textBox1.Text=wynik.ToString();
            }
        }
    }
}
