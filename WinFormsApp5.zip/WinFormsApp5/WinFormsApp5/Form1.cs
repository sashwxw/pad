namespace WinFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try 
            {
                int l;
                bool sl = int.TryParse(textBox1.Text, out l);
                double wynik;
                if (radioButton1.Checked)
                {
                    wynik=l*6.80;
                    textBox2.Text=wynik.ToString();
                }
                else if(radioButton2.Checked) 
                {
                    wynik = l * 7.10;
                    textBox2.Text = wynik.ToString();
                }
                else if (radioButton3.Checked)
                {
                    wynik = l * 6.90;
                    textBox2.Text = wynik.ToString();
                }
                else if (radioButton4.Checked)
                {
                    wynik = l * 2.90;
                    textBox2.Text = wynik.ToString();
                }
                else
                {
                    MessageBox.Show("");
                }
            }
            catch
            {

            }
            
        }
    }
}
