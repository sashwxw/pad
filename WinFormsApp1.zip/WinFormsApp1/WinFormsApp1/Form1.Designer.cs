﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBoxA = new TextBox();
            textBoxB = new TextBox();
            Wybor = new GroupBox();
            radioButtonPlus = new RadioButton();
            radioButtonMinus = new RadioButton();
            radioButtonMnoz = new RadioButton();
            radioButtonDziel = new RadioButton();
            Oblicz = new Button();
            textBox1 = new TextBox();
            Wybor.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 33);
            label1.Name = "label1";
            label1.Size = new Size(19, 15);
            label1.TabIndex = 0;
            label1.Text = "a: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(197, 33);
            label2.Name = "label2";
            label2.Size = new Size(17, 15);
            label2.TabIndex = 1;
            label2.Text = "b:";
            // 
            // textBoxA
            // 
            textBoxA.Location = new Point(50, 30);
            textBoxA.Name = "textBoxA";
            textBoxA.Size = new Size(100, 23);
            textBoxA.TabIndex = 2;
            // 
            // textBoxB
            // 
            textBoxB.Location = new Point(220, 30);
            textBoxB.Name = "textBoxB";
            textBoxB.Size = new Size(100, 23);
            textBoxB.TabIndex = 3;
            // 
            // Wybor
            // 
            Wybor.Controls.Add(radioButtonDziel);
            Wybor.Controls.Add(radioButtonMnoz);
            Wybor.Controls.Add(radioButtonMinus);
            Wybor.Controls.Add(radioButtonPlus);
            Wybor.Location = new Point(35, 59);
            Wybor.Name = "Wybor";
            Wybor.Size = new Size(203, 54);
            Wybor.TabIndex = 4;
            Wybor.TabStop = false;
            Wybor.Text = "Wybór";
            // 
            // radioButtonPlus
            // 
            radioButtonPlus.AutoSize = true;
            radioButtonPlus.Checked = true;
            radioButtonPlus.Location = new Point(9, 28);
            radioButtonPlus.Name = "radioButtonPlus";
            radioButtonPlus.Size = new Size(33, 19);
            radioButtonPlus.TabIndex = 0;
            radioButtonPlus.TabStop = true;
            radioButtonPlus.Text = "+";
            radioButtonPlus.UseVisualStyleBackColor = true;
            // 
            // radioButtonMinus
            // 
            radioButtonMinus.AutoSize = true;
            radioButtonMinus.Location = new Point(58, 28);
            radioButtonMinus.Name = "radioButtonMinus";
            radioButtonMinus.Size = new Size(30, 19);
            radioButtonMinus.TabIndex = 1;
            radioButtonMinus.Text = "-";
            radioButtonMinus.UseVisualStyleBackColor = true;
            // 
            // radioButtonMnoz
            // 
            radioButtonMnoz.AutoSize = true;
            radioButtonMnoz.Location = new Point(113, 28);
            radioButtonMnoz.Name = "radioButtonMnoz";
            radioButtonMnoz.Size = new Size(30, 19);
            radioButtonMnoz.TabIndex = 2;
            radioButtonMnoz.Text = "*";
            radioButtonMnoz.UseVisualStyleBackColor = true;
            // 
            // radioButtonDziel
            // 
            radioButtonDziel.AutoSize = true;
            radioButtonDziel.Location = new Point(162, 28);
            radioButtonDziel.Name = "radioButtonDziel";
            radioButtonDziel.Size = new Size(30, 19);
            radioButtonDziel.TabIndex = 3;
            radioButtonDziel.Text = "/";
            radioButtonDziel.UseVisualStyleBackColor = true;
            // 
            // Oblicz
            // 
            Oblicz.Location = new Point(35, 119);
            Oblicz.Name = "Oblicz";
            Oblicz.Size = new Size(75, 23);
            Oblicz.TabIndex = 4;
            Oblicz.Text = "Oblicz";
            Oblicz.UseVisualStyleBackColor = true;
            Oblicz.Click += Oblicz_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(35, 148);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(Oblicz);
            Controls.Add(Wybor);
            Controls.Add(textBoxB);
            Controls.Add(textBoxA);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Wybor.ResumeLayout(false);
            Wybor.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBoxA;
        private TextBox textBoxB;
        private GroupBox Wybor;
        private RadioButton radioButtonDziel;
        private RadioButton radioButtonMnoz;
        private RadioButton radioButtonMinus;
        private RadioButton radioButtonPlus;
        private Button Oblicz;
        private TextBox textBox1;
    }
}
