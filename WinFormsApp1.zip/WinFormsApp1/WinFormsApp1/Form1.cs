namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Oblicz_Click(object sender, EventArgs e)
        {
            try
            {
                double a=double.Parse(textBoxA.Text);
                double b=double.Parse(textBoxB.Text);
                double wynik;
                if(radioButtonPlus.Checked)
                {
                    wynik = a + b;
                    textBox1.Text=wynik.ToString();
                }
                else if(radioButtonMinus.Checked)
                {
                    wynik = a - b;
                    textBox1.Text = wynik.ToString();

                }
                else if (radioButtonMnoz.Checked)
                {
                    wynik = a * b;
                    textBox1.Text=wynik.ToString();
                }
                else if (radioButtonDziel.Checked){
                    if (b == 0)
                    {
                        MessageBox.Show("nie mo�na dzieli� przez 0", "B��d");
                    }
                    else
                    {
                        wynik = a / b;
                        textBox1 .Text = wynik.ToString();
                    }
                }
            
            }
            catch (FormatException)
            {
                MessageBox.Show("Wprowad� poprawne liczby", "B��d danych");
            
            }

        }
    }
}
